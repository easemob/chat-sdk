package com.hyphenate.chatdemo;

final class DemoUtils {

    private DemoUtils() {
    }

//    static void download(EMMessage message, EMChatManager.AttachmentDownloadType type, EMCallBack callback) {
//        if (type == null) {
//            if (callback != null) {
//                callback.onError(EMError.INVALID_PARAM, "Attachment download type cannot be null.");
//            }
//            return;
//        }
//
//        EMChatManager chatManager = EMClient.getInstance().chatManager();
//        switch (type) {
//            case ORIGINAL:
//                chatManager.downloadAttachment(message, callback);
//                break;
//            case BIG:
//                chatManager.downloadBigImage(message, callback);
//                break;
//            case THUMBNAIL:
//                chatManager.downloadThumbnail(message, callback);
//                break;
//            default:
//                if (callback != null) {
//                    callback.onError(EMError.INVALID_PARAM, "Unsupported attachment download type: " + type);
//                }
//                break;
//        }
//    }
}
