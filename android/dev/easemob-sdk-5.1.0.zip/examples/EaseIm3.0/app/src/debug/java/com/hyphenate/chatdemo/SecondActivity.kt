package com.hyphenate.chatdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.hyphenate.chat.EMCmdMessageBody
import com.hyphenate.chat.EMMessage
import com.hyphenate.chat.EMMessageBody
import com.hyphenate.chatdemo.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var  binding: ActivitySecondBinding
    private var userId: String = "pu"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater).apply {
            setContentView(root)
        }
        initListener()
        initData()
    }

    private fun initData() {

    }

    private fun initListener() {
        binding.btnParseCmd.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.btn_parse_cmd -> {
                parseCmd()
            }
        }

    }

    private fun parseCmd() {
        val msg1 = EMMessage.createTextSendMessage("cmd:sendMsg-123456", userId)
        val messages = arrayListOf<EMMessage>().apply {
            add(msg1)
        }
        messages.mapNotNull {
            println("it="+it)
            (it.body as? EMCmdMessageBody)?.action()?.let {
                println("action=="+it)
            }
            try {
                EMCmdMessageBody("test").action()
            } catch (e: Exception) {
                e.printStackTrace()
                println("-----------===")
            }
        }
//        var msg :EMCmdMessageBody?=null;
//        msg!!.action()

    }
}