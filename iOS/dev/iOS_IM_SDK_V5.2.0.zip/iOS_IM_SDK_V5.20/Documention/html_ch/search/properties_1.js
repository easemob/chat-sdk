var searchData=
[
  ['bigimagedownloadstatus',['bigImageDownloadStatus',['../interface_e_m_image_message_body.html#a5c166fc8e286c4d1eca7598953a77587',1,'EMImageMessageBody']]],
  ['bigimagelocalpath',['bigImageLocalPath',['../interface_e_m_image_message_body.html#abcbe7091d5be8f5a2f9a1f0fb31dfc8f',1,'EMImageMessageBody']]],
  ['bigimageremotepath',['bigImageRemotePath',['../interface_e_m_image_message_body.html#a55de39849673df0b58b8fe1e8454056a',1,'EMImageMessageBody']]],
  ['birth',['birth',['../interface_e_m_user_info.html#aaf4b803b42a52437a3438d6eafe5b3ca',1,'EMUserInfo']]],
  ['bitspersample',['bitsPerSample',['../interface_e_m_voice_param.html#a773f5624eff153c8f4d860277f5a7b37',1,'EMVoiceParam']]],
  ['blacklist',['blacklist',['../interface_e_m_chatroom.html#a1fe8db5d70110519916c4c2e1e4511fa',1,'EMChatroom::blacklist()'],['../interface_e_m_group.html#ad54a4aff8522f802f4238c588c9659c5',1,'EMGroup::blacklist()']]],
  ['bodies',['bodies',['../interface_e_m_chat_message.html#adc7fa931cd7228bd51c9be70d19385cf',1,'EMChatMessage']]],
  ['body',['body',['../interface_e_m_chat_message.html#afa78db9d43f69fd65879aa902115455f',1,'EMChatMessage::body()'],['../interface_e_m_search_server_message_result.html#a7fccb3fc313fc674a65b8b8baef9e2a0',1,'EMSearchServerMessageResult::body()']]],
  ['broadcast',['broadcast',['../interface_e_m_chat_message.html#ae270c2da86b6797658fe447ec33dc304',1,'EMChatMessage']]],
  ['buildingname',['buildingName',['../interface_e_m_location_message_body.html#a809d3ba9da893b3275707bc0fec93f4b',1,'EMLocationMessageBody']]]
];
