var searchData=
[
  ['mainpage_5fv5_5fen',['mainpage_v5_en',['../md__hyphenate_chat_8framework__headers_mainpage_v5_en.html',1,'']]],
  ['mainpage_5fv5_5fzh',['mainpage_v5_zh',['../md__hyphenate_chat_8framework__headers_mainpage_v5_zh.html',1,'']]]
];
