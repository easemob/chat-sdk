var searchData=
[
  ['namecard',['namecard',['../interface_e_m_group_member_info.html#a532849cf72c32e198fd1fb51bb87bdbb',1,'EMGroupMemberInfo']]],
  ['nickname',['nickname',['../interface_e_m_message_sender_info.html#a189fc8153375cddb13d07a68ad612b6d',1,'EMMessageSenderInfo::nickname()'],['../interface_e_m_group_member_info.html#acce77ac2098b31fe45c9d68e90455805',1,'EMGroupMemberInfo::nickname()'],['../interface_e_m_user_info.html#aea54951c9e03e57a361cfb8e010c462e',1,'EMUserInfo::nickname()']]],
  ['nsobject_28coding_29',['NSObject(Coding)',['../category_n_s_object_07_coding_08.html',1,'']]],
  ['ntpservers',['ntpServers',['../interface_e_m_options.html#a5f5ef034c36d2960ec10fca337e9182f',1,'EMOptions']]]
];
